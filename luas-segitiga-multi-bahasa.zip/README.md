# Luas Segitiga Multi Bahasa

Project ini berisi program sederhana untuk menghitung luas segitiga dalam berbagai bahasa pemrograman.

## Rumus
Luas = 0.5 × alas × tinggi

## Tujuan
Belajar berbagai bahasa pemrograman.
